# Chall-00 - Practice

想定難易度: Warmup

DevTools と JavaScript を使って Firestore からドキュメントを取得してみましょう。
