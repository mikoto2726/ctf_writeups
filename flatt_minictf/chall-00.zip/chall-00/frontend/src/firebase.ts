import { initializeApp } from 'firebase/app';

export const firebaseApp = initializeApp({
  apiKey: "AIzaSyBTn0lBewM5T7UJPY4mKhZHZCN1I6Nxzew",
  authDomain: "flatt-minictf-practice.firebaseapp.com",
  projectId: "flatt-minictf-practice",
  storageBucket: "flatt-minictf-practice.appspot.com",
  messagingSenderId: "539316080413",
  appId: "1:539316080413:web:837b1bb20d77175b3d9bf4"
});
