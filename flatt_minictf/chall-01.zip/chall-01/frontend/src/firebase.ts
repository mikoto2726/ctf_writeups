import { initializeApp } from 'firebase/app';

export const firebaseApp = initializeApp({
  apiKey: "AIzaSyDCCJ2lTAU79fC2URzG8ndw1Ee-4qvO3CM",
  authDomain: "flatt-minictf-internal.firebaseapp.com",
  projectId: "flatt-minictf-internal",
  storageBucket: "flatt-minictf-internal.appspot.com",
  messagingSenderId: "662671516916",
  appId: "1:662671516916:web:8ca0e3a5fd923f4ccaaaa1"
});
